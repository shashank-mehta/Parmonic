This application is build using .NET 6 Console. 

==>Functionality<==
This application accepts a number from the user and verifies if the is divisible by 3 or 5 or 3 & 5 and prints appropriate messages on console. It validates the number entered by the user is a legal number and if not it would show a note in red font that invalid number entered and would request user add a new number again.

==>Technology & Project structure
=>ParnomicUnitTest - This is console application which has the business logic for verifying the entered number is divisible and print an appropriate message.
1. Math.cs class has the business logic get a number from the user and also verify if that's a valid number and print the message on console.
2. Program.cs class is using the Math static class to invoke the business functionality.

=>UnitTestConsole - This project has the Nunit test case for testing the functionality built in the Math class.
