using NUnit.Framework;
using ParmonicUnitTest;

namespace UnitTest
{
    public class Tests
    { 

     
       
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void DivisiblebyThreeFalse()
        {
            var result = Maths.IsDivisible(1);
            Assert.AreEqual(result, "1");            
        }

        [Test]
        public void DivisiblebyThreeTrue()
        {
            var result = Maths.IsDivisible(3);
            Assert.AreEqual(result, "Fizz");
        }


        [Test]
        public void DivisiblebyFiveTrue()
        {
            var result = Maths.IsDivisible(5);
            Assert.AreEqual(result, "Buzz");
        }

        [Test]
        public void DivisiblebyFiveFalse()
        {
            var result = Maths.IsDivisible(1);
            Assert.AreEqual(result, "1");
        }

        [Test]
        public void DivisiblebyFiveandThreeTrue()
        {
            var result = Maths.IsDivisible(45);
            Assert.AreEqual(result, "FizzBuzz");
        }

        /// <summary>
        /// There is no need to validate the input is number as it is managed in when we are reading the value from console.
        /// </summary>
    }
}
