﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParmonicUnitTest
{
    public static class Maths
    {
        /// <summary>
        /// This method takes a number and validate if thats a correct number
        /// </summary>
        /// <returns></returns>
       public static int GetNumber()
        {
            int? i;
            start:
            try
            {
                Console.Write("Enter a number: ");
                i = int.Parse(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid Number. Please enter a valid number");
                Console.ForegroundColor = ConsoleColor.White;
                goto start;
            }
            Console.Clear();
            return i.Value;
        }

        /// <summary>
        /// This method will check the input number is divisible by 3 or 5 or 3 & 5 
        /// </summary>
        /// <param name="i">Pass a valid number</param>
       public static string IsDivisible(int i)
        {
            var str = i.ToString();

            if (i % 3 == 0 && i % 5 == 0)
                str = "FizzBuzz";
            else if (i % 3 == 0)
                str = "Fizz";
            else if (i % 5 == 0)
                str = "Buzz";

            return str;
        }
    }
}
