﻿using ParmonicUnitTest;

//Start of the application
try
{
    int i = Maths.GetNumber();
    var str = Maths.IsDivisible(i);
    Console.WriteLine(str);
}
catch (Exception ex)
{
    Console.WriteLine(ex.ToString());
}
finally { Console.ReadLine(); }


