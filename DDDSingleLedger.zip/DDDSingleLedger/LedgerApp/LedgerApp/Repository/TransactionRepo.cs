﻿using LedgerApp.Contract;
using LedgerApp.Entities;
using System.Transactions;

namespace LedgerApp.Repository
{
    public class TransactionRepo : ITransaction
    {
        private readonly ApplicationDBContext _dbContext;
        public TransactionRepo(ApplicationDBContext context)
        {
            _dbContext = context;
        }
        public IEnumerable<Trans> GetTransactions()
        {
            return _dbContext.Trans.OrderByDescending(a=>a.TransId).ToList();
        }

        public int PostTransactions(Trans transaction)
        {

            using (TransactionScope scope = new(TransactionScopeOption.Required, new TransactionOptions {
                IsolationLevel = IsolationLevel.ReadUncommitted}))
            {
                var bal = _dbContext.Trans.OrderByDescending(a => a.TransId).Select(a => a.Balance).FirstOrDefault();
                if (transaction.TransType == "Debit")
                    transaction.Balance = decimal.Subtract( bal, transaction.Amount);
                else
                    transaction.Balance = decimal.Add(transaction.Amount, bal);

                transaction.TransDate = DateTime.Now;
                _dbContext.Trans.Add(transaction);
                _dbContext.SaveChanges();

                //do your code or write your query.
                scope.Complete();
            }
          
            return 1;
        }
    }
}
