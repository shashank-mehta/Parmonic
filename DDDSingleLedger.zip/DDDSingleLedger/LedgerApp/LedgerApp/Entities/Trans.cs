﻿using System.ComponentModel.DataAnnotations;

namespace LedgerApp.Entities
{
    public class Trans
    {
        [Key]
        public int TransId { get; set; }

        [Required (ErrorMessage ="Please select Transaction Type")]
        public string TransType { get; set; }
        [Required (ErrorMessage ="Please enter Description")]
        public string Description { get; set; }

        [Range(1, Int32.MaxValue,ErrorMessage ="Amount cannot be Zero")]
        public decimal Amount { get; set; }
        public decimal Balance { get; set; }

        public DateTime TransDate { get; set; }

        
    }
}
