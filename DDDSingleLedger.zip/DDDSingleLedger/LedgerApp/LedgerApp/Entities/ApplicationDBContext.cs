﻿using Microsoft.EntityFrameworkCore;

namespace LedgerApp.Entities
{
    public class ApplicationDBContext: DbContext
    {
        public ApplicationDBContext(DbContextOptions options): base(options)
        {

        }

        public DbSet<Trans> Trans { get; set; }
       
    }
}
