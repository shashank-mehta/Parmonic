﻿using LedgerApp.Entities;
using LedgerApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using LedgerApp.Contract;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LedgerApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ITransaction _trans;

        public HomeController(ILogger<HomeController> logger, ITransaction trans)
        {
            _logger = logger;
            _trans= trans;
        }

        public IActionResult Index()
        {
            return View(_trans.GetTransactions());
        }

        public IActionResult AddTransaction()
        {
            try
            {
                TransTypeDll();
                ViewBag.LowBalance = false;
                var bal = _trans.GetTransactions().OrderByDescending(a => a.TransId).Select(a => a.Balance).FirstOrDefault();
                return View(new Trans { Balance = bal });
            }
            catch (Exception ex)
            {
                //Code to log exception
                return RedirectToAction("Error");
            }            
        }

        [HttpPost]
        public dynamic SaveTransaction(Trans extn)
        {
            try
            {
                ViewBag.LowBalance = extn.TransType == "Debit" && ((extn.Balance - extn.Amount) < 0);

                if (ModelState.IsValid && !ViewBag.LowBalance)
                {
                    ViewBag.LowBalance = false;
                    _trans.PostTransactions(extn);
                    return RedirectToAction("Index");
                }
                TransTypeDll();
                return View("AddTransaction", extn);
            }
            catch (Exception ex)
            {
                //Code to log exception
                return RedirectToAction("Error");
            }
            
        }           
           
        private void TransTypeDll()
        {
            ViewBag.TransType = new List<SelectListItem>
            {
                new SelectListItem { Value = "Credit", Text = "Credit" },
                new SelectListItem { Value = "Debit", Text = "Debit" }
            };

        }
        

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}