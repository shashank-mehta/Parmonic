﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LedgerApp.Migrations
{
    public partial class initial1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Trans_TransDetails_TransDetailId",
                table: "Trans");

            migrationBuilder.DropIndex(
                name: "IX_Trans_TransDetailId",
                table: "Trans");

            migrationBuilder.DropColumn(
                name: "TransDetailId",
                table: "Trans");

            migrationBuilder.AddColumn<int>(
                name: "TransactionTransId",
                table: "TransDetails",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_TransDetails_TransactionTransId",
                table: "TransDetails",
                column: "TransactionTransId");

            migrationBuilder.AddForeignKey(
                name: "FK_TransDetails_Trans_TransactionTransId",
                table: "TransDetails",
                column: "TransactionTransId",
                principalTable: "Trans",
                principalColumn: "TransId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TransDetails_Trans_TransactionTransId",
                table: "TransDetails");

            migrationBuilder.DropIndex(
                name: "IX_TransDetails_TransactionTransId",
                table: "TransDetails");

            migrationBuilder.DropColumn(
                name: "TransactionTransId",
                table: "TransDetails");

            migrationBuilder.AddColumn<int>(
                name: "TransDetailId",
                table: "Trans",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Trans_TransDetailId",
                table: "Trans",
                column: "TransDetailId");

            migrationBuilder.AddForeignKey(
                name: "FK_Trans_TransDetails_TransDetailId",
                table: "Trans",
                column: "TransDetailId",
                principalTable: "TransDetails",
                principalColumn: "TransDetailId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
