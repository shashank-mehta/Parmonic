﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LedgerApp.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TransDetails",
                columns: table => new
                {
                    TransDetailId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TransDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TransDetails", x => x.TransDetailId);
                });

            migrationBuilder.CreateTable(
                name: "Trans",
                columns: table => new
                {
                    TransId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TransType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Balance = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TransDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TransDetailId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Trans", x => x.TransId);
                    table.ForeignKey(
                        name: "FK_Trans_TransDetails_TransDetailId",
                        column: x => x.TransDetailId,
                        principalTable: "TransDetails",
                        principalColumn: "TransDetailId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Trans_TransDetailId",
                table: "Trans",
                column: "TransDetailId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Trans");

            migrationBuilder.DropTable(
                name: "TransDetails");
        }
    }
}
