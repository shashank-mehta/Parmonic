﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LedgerApp.Migrations
{
    public partial class initial2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TransDetails");

            migrationBuilder.AddColumn<string>(
                name: "Description",
                table: "Trans",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Description",
                table: "Trans");

            migrationBuilder.CreateTable(
                name: "TransDetails",
                columns: table => new
                {
                    TransDetailId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TransactionTransId = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TransDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TransDetails", x => x.TransDetailId);
                    table.ForeignKey(
                        name: "FK_TransDetails_Trans_TransactionTransId",
                        column: x => x.TransactionTransId,
                        principalTable: "Trans",
                        principalColumn: "TransId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TransDetails_TransactionTransId",
                table: "TransDetails",
                column: "TransactionTransId");
        }
    }
}
