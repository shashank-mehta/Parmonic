﻿using LedgerApp.Entities;

namespace LedgerApp.Contract
{
    public interface ITransaction
    {
        public IEnumerable<Trans> GetTransactions();
        public int PostTransactions(Trans transaction);

    }
}
