Single Entry Ledger

The application is built using .NET 6 MVC and EF Core connecting to SQL DB. 
There are two Menu on the top of the home page, Report & Add Transactions

==>APPLICATION FUNCTIONALITY<==

=>Report page show all the transactions in the cash ledger, following are columns
1. Transaction Date - This is the date of transaction on which the amount is credited/debited
2. Description - This column captures notes for which the amount is debited/credited.
3. Debit - This column would show a record if the amount was debited from the ledger and would show in red font
4. Credit - This column would show a record if the amount is credited in the ledger and would show in green font
5. Current Balance - This is the running balance which would always be current

=>Add Transaction - This page will allow adding new transactions
1. Current Balance - This shows the current balance in the ledger. This could not be negative, there is a validation on the balance amount.
2. Transaction Type - This is a select option with two choices "Debit" and "Credit" and depending upon the selection the amount would be credited or debited in the ledger
3. Description -  This column captures notes for which the amount is debited/credited.
4. Amount - This is the amount that would either get credited or debited depending upon the option selected in the Transaction Type dropdown. The value in this field cannot be more than the Current Balance as the cash ledger cannot have a negative balance. There is validation, if the amount is more than the Current Balance and the transaction type selected is debit then it would show the Current balance in Red indicating the balance is low and cannot debit.

All the fields on the form are mandatory and validation is implemented by data annotations.


==>TECHNOLOGY AND STRUCTURE<==
=> FOLDER
1. Contract - This folder has the interface for transaction
2. Controller - This folder has the MVC controller 
3. Entities - This folder has the POCO objects and DBContext class
4. Migration - This folder has the DB migration class (Code First approach)
5. Repository - This folder has the class with business logic where interface is implemented
6. View - This folder has the views for UI

=> Program.cs
1. Dependency Injection used for implementing interface
2. DBContext Service adding for SQLServer 
3. AppSetting.json has the connection string

==>Short Comings
I have not worked on Domain Driven Design for EF so I was not able to implement it in that pattern but I have implemented the entities using EF Code First Approach.
