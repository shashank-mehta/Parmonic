RateLimitingAPI

This application is a restriction the number of hits to the API to a maximum in 1 second.

==>Technology<==
1. WebAPI is built using .NET 6 framework
=> Folder Structure
1. Controller - This folder has the controller with API methods. Using AttributeMethod I have passed the value of the max number of requests and number of seconds it should be restricted
2. Extension - This folder has extension methods used for a byte to JSON conversion and reverse
3. Middleware - This folder has the class file for rate-limiting middleware
4. Program.cs - In this file, I am using the middleware so for every request it would check first the no of hits for the IP and then invoke the actual method. If the number of hits exceeds the maximum allowed time, I am returning Http Status as TooManyRequests.

If you try to run this app, there could be a possibility that swagger might not load and you may see an error, just route the URL to the controller.
