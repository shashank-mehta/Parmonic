﻿using Microsoft.Extensions.Caching.Distributed;
using System.Net;

namespace RateLimiting
{

    public class RateLimitingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IDistributedCache _cache;

        public RateLimitingMiddleware(RequestDelegate next, IDistributedCache cache)
        {
            _next = next;
            _cache = cache;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var endpoint = context.GetEndpoint();
            var rateLimitingDecorator = endpoint?.Metadata.GetMetadata<LimitDetails>();

            if (rateLimitingDecorator is null)
            {
                await _next(context);
                return;
            }

            var key = context.Request.Path + "_" + context.Connection.RemoteIpAddress;
            var reqDetails = await GetRequestDetailsByKey(key);

            if (reqDetails != null && DateTime.UtcNow < reqDetails.LastLoginTime.AddSeconds(rateLimitingDecorator.Seconds) 
                    && reqDetails.NumberOfRequests == rateLimitingDecorator.RequestsAllowed)
            {
                context.Response.StatusCode = (int)HttpStatusCode.TooManyRequests;
                return;
            }

            await UpdateCacheDetails(key, rateLimitingDecorator.RequestsAllowed);
            await _next(context);
        }
             
        private async Task<RequestDetails> GetRequestDetailsByKey(string key)
        { 
            var result =  await _cache.GetAsync(key,CancellationToken.None);
            return result.FromByteArray<RequestDetails>();
        }

        private async Task UpdateCacheDetails(string key, int maxRequests)
        {
            var result = await _cache.GetAsync(key, CancellationToken.None);
            var reqDetails = result.FromByteArray<RequestDetails>();

            if (reqDetails != null)
            {
                reqDetails.LastLoginTime = DateTime.UtcNow;

                if (reqDetails.NumberOfRequests == maxRequests)
                    reqDetails.NumberOfRequests = 1;

                else
                    reqDetails.NumberOfRequests++;

                var bytes = reqDetails.ToByteArray();
                await _cache.SetAsync(key,bytes);
            }
            else
            {
                var reqDetailsN = new RequestDetails
                {
                    LastLoginTime = DateTime.UtcNow,
                    NumberOfRequests = 1
                };

                var bytes = reqDetailsN.ToByteArray();
                await _cache.SetAsync(key, bytes);
            }

        }
    }

    public class RequestDetails
    {
        public DateTime LastLoginTime { get; set; }
        public int NumberOfRequests { get; set; }
    }


    /// <summary>
    /// Decorate Attribute on methods
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public class LimitDetails : Attribute
    {
        public int Seconds { get; set; }
        public int RequestsAllowed { get; set; }
    }

    /// <summary>
    /// Middleware extension to use as middleware in program.cs
    /// </summary>
    public static class MiddlewareExtensions
    {
        public static IApplicationBuilder UseRateLimiting(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RateLimitingMiddleware>();
        }
    }
}

